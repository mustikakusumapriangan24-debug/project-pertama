class Food {
  final String title;
  final List<String> images; // carousel images (at least 1)
  final String desc;
  final String category; // "Makanan" or "Minuman"

  const Food({
    required this.title,
    required this.images,
    required this.desc,
    required this.category,
  });
}
