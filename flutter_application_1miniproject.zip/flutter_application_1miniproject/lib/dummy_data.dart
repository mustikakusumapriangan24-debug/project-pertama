import 'food_model.dart';

const List<Food> foods = [
  Food(
    title: 'Colenak',
    images: ['assets/images/colenak.jpg'],
    category: 'Makanan',
    desc: """
Colenak adalah makanan tradisional khas Sunda (Jawa Barat, Indonesia) yang terbuat dari peuyeum (tape singkong fermentasi) yang dibakar lalu disajikan dengan saus kinca — campuran gula merah dan santan.

Nama "Colenak" berasal dari "dicocol enak". Biasanya peuyeum dibakar hingga bagian luar sedikit garing namun dalamnya tetap lembut. Saus kinca disiram atau dipakai sebagai cocolan.

Bahan utama:
- Peuyeum (tape singkong)
- Gula merah
- Santan
- Daun pandan
- Sedikit garam
""",
  ),

  Food(
    title: 'Bajigur',
    images: ['assets/images/bajigur.jpg'],
    category: 'Minuman',
    desc: 'Bajigur adalah minuman tradisional panas khas Sunda yang terbuat dari santan dan gula aren, biasa dinikmati saat cuaca dingin.',
  ),

  Food(
    title: 'Batagor',
    images: ['assets/images/batagor.jpg'],
    category: 'Makanan',
    desc: 'Batagor adalah bakso tahu goreng khas Bandung disajikan dengan saus kacang yang gurih.',
  ),

  Food(
    title: 'Ubi Cilembu',
    images: ['assets/images/cilembu.jpg'],
    category: 'Makanan',
    desc: 'Ubi manis Cilembu, teksturnya lembut dan legit saat dipanggang.',
  ),

  Food(
    title: 'Cuanki',
    images: ['assets/images/cuanki.jpg'],
    category: 'Makanan',
    desc: 'Cuanki Bandung, semangkuk kuah dengan bakso, siomay, dan gorengan kecil.',
  ),

  // tambahkan lebih banyak sesuai daftarmu...
];
