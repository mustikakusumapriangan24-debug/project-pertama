import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'favorite_provider.dart';
import 'dummy_data.dart';
import 'detail_page.dart';

class FavoritesPage extends StatelessWidget {
  const FavoritesPage({super.key});

  @override
  Widget build(BuildContext context) {
    final favProv = Provider.of<FavoriteProvider>(context);
    final favTitles = favProv.favorites;
    final favItems = foods.where((f) => favTitles.contains(f.title)).toList();

    return Scaffold(
      appBar: AppBar(title: const Text('Favorit Saya')),
      body: favItems.isEmpty
          ? const Center(child: Text('Belum ada favorit', style: TextStyle(fontSize: 16)))
          : ListView.builder(
              itemCount: favItems.length,
              itemBuilder: (context, i) {
                final f = favItems[i];
                return ListTile(
                  leading: Image.asset(f.images.first, width: 56, height: 56, fit: BoxFit.cover),
                  title: Text(f.title),
                  subtitle: Text(f.category),
                  onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => DetailPage(food: f))),
                );
              },
            ),
    );
  }
}
