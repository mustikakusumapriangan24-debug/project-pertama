import 'package:flutter/foundation.dart';

class FavoriteProvider extends ChangeNotifier {
  final Set<String> _favorites = {};
  final Map<String, double> _ratings = {}; // key: title, value: rating 0..5

  bool isFavorite(String title) => _favorites.contains(title);

  void toggleFavorite(String title) {
    if (_favorites.contains(title)) {
      _favorites.remove(title);
    } else {
      _favorites.add(title);
    }
    notifyListeners();
  }

  Set<String> get favorites => _favorites;

  double getRating(String title) => _ratings[title] ?? 0.0;

  void setRating(String title, double rating) {
    _ratings[title] = rating;
    notifyListeners();
  }
}
